       @foreach ($data as $chart_data)
                @php
                      $chart = DB::table('chart_data')
                        ->where('kpi_setting_id', $chart_data->id)
                        ->whereNotNull('target_value')
                        ->orderby('id','DESC')
                        ->first();
    
                    
                    $alldata = DB::table('chart_data')
                        ->whereNotNull('target_value')
                        ->whereRaw('target_value REGEXP "^[0-9]+$"')
                        ->get();                   
                @endphp

                @if ($chart_data->chart_type == 'Line')
                    <div class="col-md-6 mb-5">
                        <div class="card p-3 mt-2">
                            <div class="card-body">
                                <div class="row chart-header mb-5">
                                    <div class="col-md-12">
                                        <div class="d-flex flex-row">
                                            <div>
                                                <h3 class="title mb-1">{{$chart_data->chart_title}}</h3>
                                                <small class="subtitle">{{$chart_data->chart_subtitle}}</small>
                                            </div>
                                            <div class="d-flex justify-content-between ml-auto">
                                                <div class="d-flex flex-column stats-section mr-7">
                                                    <div><b>{{ $chart_data->t_value }}</b></div>
                                                    <div><small>Target Value</small></div>
                                                </div>
                                                <div class="d-flex flex-column stats-section mr-7">
                                                    <div>
                                                        <b>{{ \Carbon\Carbon::parse($chart_data->t_date)->format('M d Y') }}</b>
                                                    </div>
                                                    <div><small>Target Releases</small></div>
                                                </div>
                                                <div>
                                                    <div class="dropdown">
                                                        <button class="btn btn-circle btn-xl btn-tolbar dropdown-toggle"
                                                            type="button" id="dropdownMenuButton" data-toggle="dropdown"
                                                            aria-haspopup="true" aria-expanded="false">
                                                            <img src="{{ asset('assets/images/icons/dots.svg') }}">
                                                        </button>
                                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                            <a class="dropdown-item" href="javascript:void(0);"
                                                                onclick="editchart({{ $chart_data->id }});" data-toggle="modal"
                                                                data-target="#edit-chart">Edit Values</a>
                                                                <a class="dropdown-item" href="javascript:void(0);"
                                                                onclick="editbasicchart({{$chart_data->id}})"
                                                                data-toggle="modal" data-target="#edit-basic-chart">Edit Basic Detail</a>
                                                            <a class="dropdown-item" href="javascript:void(0);"
                                                                onclick="deletechart({{ $chart_data->id }});"
                                                                data-toggle="modal" data-target="#delete-chart">Delete chart</a>
                                                               
                                                            <a class="dropdown-item" href="{{url('download/'.$chart_data->csv)}}">Download csv</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                @php
                                    $months = [];
                                    $value = [];
                                    foreach ($alldata as $month) {
                                        if ($month->kpi_setting_id == $chart_data->id) {
                                            $months[] = $month->target_month;
                                            $value[] = $month->target_value;
                                        }
                                    }
                                @endphp
                                <canvas id="lineChart{{ $chart_data->id }}" width="800" height="400"></canvas>
                                @foreach ($alldata as $graph)
                                    @if ($graph->kpi_setting_id == $chart_data->id)
                                        @php
                                            $max = max($value);
                                            $trend = 0;
                                            if ($chart_data->trend_line == 'Yes') {
                                                $trend = $max;
                                            }
                                            
                                            $maxlinebar = 0;
                                            $maxlinebar = max($value);
                                        $extraLineData = 0;    
                                        if($chart_data->t_value != NULL)
                                        {
                                        $extraLineData = $chart_data->t_value;
                                        }
                                        
                                        $extraLineDataG = 0;
                                        $color = '';
                                        if($chart_data->target_opt == 'Greater')
                                        {
                                        $extraLineDataG = $chart_data->green;
                                        $color = 'green';
                                        }
                                        if($chart_data->target_opt == 'Less')
                                        {
                                        $extraLineDataG = $chart_data->green;
                                        $color = 'red';
                                        } 
                                        @endphp

                                        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
                                        <script>
                                            var chartData{{ $graph->id }} = @json($graph);

                                            var ctxLine{{ $graph->id }} = document.getElementById('lineChart{{ $graph->kpi_setting_id }}').getContext(
                                                '2d');

                                            var trendLineValue = "{{ $trend }}";
                                             var maxLinebar = @json($maxlinebar);
                                        
                                              var calculatedMaxbar = Math.ceil(maxLinebar / 25) * 25;
                                              var calculatedMaxbarNew = (calculatedMaxbar + 100);
                                              var extraLineData = "{{$extraLineData}}";
                                              var extraLineDataG = "{{$extraLineDataG}}";
                                               var color = "{{$color}}";
                                            new Chart(ctxLine{{ $graph->id }}, {
                                                type: 'line', // Corrected to create a line chart
                                                data: {
                                                    labels: @json($months),
                                                    datasets: [{
                                                            label: 'Values',
                                                            data: @json($value),
                                                            backgroundColor: 'rgba(84, 122, 255, 0.1)',
                                                            borderColor: '#547AFF',
                                                            borderWidth: 3,
                                                            fill: true,
                                                        },
                                                        {
                                                            label: 'Trend Line',
                                                            data: Array.from({
                                                                length: @json($months).length
                                                            }, () => trendLineValue),
                                                            borderColor: '#36a2eb', // Hex code for red
                                                            borderWidth: 2,
                                                            fill: false // No fill for trend line
                                                        },
                                                         {
                                                            label: 'Target Line',
                                                            data: Array.from({
                                                            length: @json($months).length
                                                            }, () => extraLineData),
                                                            borderColor: 'yellow', // Hex code for red
                                                            borderWidth: 2,
                                                            fill: false // No fill for trend line
                                                          
                                                        },
                                                        
                                                         {
                                                            label: 'Green Line',
                                                            data: Array.from({
                                                            length: @json($months).length
                                                            }, () => extraLineDataG),
                                                            borderColor: color, // Hex code for red
                                                            borderWidth: 2,
                                                            fill: false // No fill for trend line
                                                          
                                                        },
                                                    ]
                                                },
                                                options: {
                                                    scales: {
                                                        x: {
                                                            grid: {
                                                                color: '#fff' // Change color of horizontal grid lines
                                                            },
                                                            ticks: {
                                                                maxRotation: 0,
                                                                autoSkip: true,
                                                                maxTicksLimit: 12
                                                            }
                                                        },
                                                        y: {
                                                            grid: {
                                                                color: '#EAEAEA' // Change color of horizontal grid lines
                                                            },
                                                            beginAtZero: true,
                                                            max:calculatedMaxbarNew,
                                                            stepSize:100
                                                        }
                                                    }
                                                }
                                            });
                                        </script>
                                    @endif
                                @endforeach
                            </div>
                            <div class="card-footer">
                                <div class="d-flex justify-content-between">
                                    <div class="d-flex flex-row align-items-center">
                                        <div class="mr-2"><b>Updated on</b></div>
                                        <div>
                                            <small>{{ \Carbon\Carbon::parse($chart_data->updated_at)->format('M d Y') }}</small>
                                        </div>
                                    </div>
                                    <div class="d-flex flex-row align-items-center">
                                        @if($chart_data)
                                        @if ($chart_data->target_option == 'yes')
                                        @if ($chart_data->target_opt == 'Greater')
                                            @if ($chart->target_value > $chart_data->green)
                                                 <div class="mr-2">
                                                    <div class="circle green"></div>
                                                </div>
                                                <div><small>Status (Green)</small></div>
                                               @else        
                                                <div class="mr-2">
                                                    <div class="circle red"></div>
                                                </div>
                                                <div><small>Status (Red)</small></div>
                                            @endif
                                            @endif
                                            
                                            @if ($chart_data->target_opt == 'Less')
                                            @if ($chart->target_value < $chart_data->green)
                                                <div class="mr-2">
                                                    <div class="circle green"></div>
                                                </div>
                                                <div><small>Status (Green)</small></div>
                                            @else
                                             <div class="mr-2">
                                                    <div class="circle red"></div>
                                                </div>
                                                <div><small>Status (Red)</small></div>
                                            @endif
                                            @endif
                                        @else
                                            @if ($chart->target_value < $chart_data->green)
                                                <div class="mr-2">
                                                    <div class="circle green"></div>
                                                </div>
                                                <div><small>Status (Green)</small></div>
                                            @elseif($chart->target_value > $chart_data->red)
                                                <div class="mr-2">
                                                    <div class="circle red"></div>
                                                </div>
                                                <div><small>Status (Red)</small></div>
                                            @else
                                                <div class="mr-2">
                                                    <div class="circle amber"></div>
                                                </div>
                                                <div><small>Status (Amber)</small></div>
                                            @endif
                                        @endif
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                @endif
            @endforeach



            @foreach ($data as $chart_data)
                @php
                    $chart = DB::table('chart_data')
                        ->where('kpi_setting_id', $chart_data->id)
                        ->whereNotNull('target_value')
                        ->orderby('id', 'DESC')
                        ->first();
                @endphp
                @if ($chart_data->chart_type == 'Bar')
                    <div class="col-md-6 mb-5">
                        <div class="card p-3 mt-2">
                            <div class="card-body">
                                <div class="row chart-header mb-5">
                                    <div class="col-md-12">
                                        <div class="d-flex">
                                            <div>
                                               <h3 class="title mb-1">{{$chart_data->chart_title}}</h3>
                                                <small class="subtitle">{{$chart_data->chart_subtitle}}</small>
                                            </div>
                                            <div class="ml-auto d-flex justify-content-between">
                                                <div class="d-flex flex-column stats-section">
                                                    <div><b>{{ $chart_data->t_value }}</b></div>
                                                    <div><small>Target Value</small></div>
                                                </div>
                                                <div class="d-flex flex-column stats-section">
                                                    <div>
                                                        <b>{{ \Carbon\Carbon::parse($chart_data->t_date)->format('M d Y') }}</b>
                                                    </div>
                                                    <div><small>Target Releases</small></div>
                                                </div>
                                                <div class="dropdown">
                                                    <button class="btn btn-circle btn-xl btn-tolbar dropdown-toggle"
                                                        type="button" id="dropdownMenuButton" data-toggle="dropdown"
                                                        aria-haspopup="true" aria-expanded="false">
                                                        <img src="{{ asset('assets/images/icons/dots.svg') }}">
                                                    </button>
                                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                        <a class="dropdown-item" href="#"
                                                            onclick="editchart({{ $chart_data->id }});" data-toggle="modal"
                                                            data-target="#edit-chart">Edit Values</a>
                                                            <a class="dropdown-item" href="javascript:void(0);"
                                                            onclick="editbasicchart({{$chart_data->id}})"
                                                            data-toggle="modal" data-target="#edit-basic-chart">Edit Basic Detail</a>
                                                        <a class="dropdown-item" href="#"
                                                            onclick="deletechart({{ $chart_data->id }});" data-toggle="modal"
                                                            data-target="#delete-chart">Delete chart</a>
                                                            <a class="dropdown-item" href="{{url('download/'.$chart_data->csv)}}">Download csv</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                @php
                                    $months = [];
                                    $value = [];
                                    foreach ($alldata as $month) {
                                        if ($month->kpi_setting_id == $chart_data->id) {
                                            $months[] = $month->target_month;
                                            $value[] = $month->target_value;
                                        }
                                    }
                                @endphp
                                <canvas id="barChart{{ $chart_data->id }}" width="800" height="400"></canvas>
                                
                                @foreach ($alldata as $graph)
                                    @if ($graph->kpi_setting_id == $chart_data->id)
                                     @php
                                            $max = max($value);
                                            $trend = 0;
                                            if ($chart_data->trend_line == 'Yes') {
                                                $trend = $max;
                                            }
                                            
                                            $maxlinebar = 0;
                                            $maxlinebar = max($value);
                                            
                                        $extraLineData = 0;    
                                        if($chart_data->t_value != NULL)
                                        {
                                        $extraLineData = $chart_data->t_value;
                                        }
                                        
                                        $extraLineDataG = 0;
                                        $color = '';
                                        if($chart_data->target_opt == 'Greater')
                                        {
                                        $extraLineDataG = $chart_data->green;
                                        $color = 'green';
                                        }
                                        if($chart_data->target_opt == 'Less')
                                        {
                                        $extraLineDataG = $chart_data->green;
                                        $color = 'red';
                                        } 
                                        @endphp
                                        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
                                        <script>
                                            var chartData{{ $graph->id }} = @json($graph);

                                            var ctxBar{{ $graph->id }} = document.getElementById('barChart{{ $graph->kpi_setting_id }}').getContext(
                                                '2d');

                                       var trendLineValue = "{{$trend}}";
                                        var maxlinebar = @json($maxlinebar);
                                        var extraLineData = "{{$extraLineData}}";
                                        var extraLineDataG = "{{$extraLineDataG}}";
                                         var color = "{{$color}}";     
                                        var calculatedMax = Math.ceil(maxlinebar / 25) * 25;
                                        var calculatedMaxbarNew = (calculatedMax + 100);

                                            new Chart(ctxBar{{ $graph->id }}, {
                                                type: 'bar',
                                                data: {
                                                    labels: @json($months),
                                                    datasets: [{
                                                        label: 'Value',
                                                        data: @json($value),
                                                        backgroundColor: '#547AFF', // Bar color
                                                        borderWidth: 0, // No borders
                                                        barThickness: 10, // Set custom bar width
                                                        pointRadius: 100 // Remove circular dots
                                                    },
                                                        {
                                                           
                                                       label: 'Trend Line',
                                                            data: Array.from({
                                                                length: @json($months).length
                                                            }, () => trendLineValue),
                                                            borderColor: '#49D518', // Hex code for red
                                                            borderWidth: 2,
                                                            fill: false,
                                                            type: 'line',
                                                        },
                                                          {
                                                            label: 'Target Line',
                                                            data: Array.from({
                                                            length: @json($months).length
                                                            }, () => extraLineData),
                                                            borderColor: 'yellow', // Hex code for red
                                                            borderWidth: 2,
                                                            fill: false, // No fill for trend line
                                                            type: 'line',
                                                          
                                                        },
                                                        
                                                         {
                                                            label: 'Green Line',
                                                            data: Array.from({
                                                            length: @json($months).length
                                                            }, () => extraLineDataG),
                                                            borderColor:color, // Hex code for red
                                                            borderWidth: 2,
                                                            fill: false, // No fill for trend line
                                                            type: 'line',
                                                          
                                                        },
                                                        
                                                        ]
                                                },
                                                options: {
                                                    scales: {
                                                        x: {
                                                            grid: {
                                                                color: 'transparent', // Hide grid lines
                                                            }
                                                        },
                                                        y: {
                                                            grid: {
                                                                color: '#EAEAEA', // Horizontal grid line color
                                                            },
                                                            beginAtZero:true,
                                                            max: calculatedMaxbarNew,
                                                            stepSize:100
                                                        }
                                                    },
                                                    plugins: {
                                                        legend: {
                                                            display: true // Hide legend
                                                        }
                                                    },
                                                    layout: {
                                                        padding: {
                                                            left: 10, // Add some padding to the left
                                                            right: 10 // Add some padding to the right
                                                        }
                                                    }
                                                }
                                            });
                                        </script>
                                    @endif
                                @endforeach


                            </div>
                            <div class="card-footer">
                                <div class="d-flex justify-content-between">
                                    <div class="d-flex flex-row">
                                        <div class="mr-2"><b>Updated on</b></div>
                                        <div>
                                            <small>{{ \Carbon\Carbon::parse($chart_data->updated_at)->format('M d Y') }}</small>
                                        </div>
                                    </div>
                                 <div class="d-flex flex-row align-items-center">
                                        @if($chart_data)
                                        @if ($chart_data->target_option == 'yes')
                                        @if ($chart_data->target_opt == 'Greater')
                                            @if ($chart->target_value > $chart_data->green)
                                                 <div class="mr-2">
                                                    <div class="circle green"></div>
                                                </div>
                                                <div><small>Status (Green)</small></div>
                                               @else        
                                                <div class="mr-2">
                                                    <div class="circle red"></div>
                                                </div>
                                                <div><small>Status (Red)</small></div>
                                            @endif
                                            @endif
                                            
                                            @if ($chart_data->target_opt == 'Less')
                                            @if ($chart->target_value < $chart_data->green)
                                                <div class="mr-2">
                                                    <div class="circle green"></div>
                                                </div>
                                                <div><small>Status (Green)</small></div>
                                            @else
                                             <div class="mr-2">
                                                    <div class="circle red"></div>
                                                </div>
                                                <div><small>Status (Red)</small></div>
                                            @endif
                                            @endif
                                        @else
                                            @if ($chart->target_value > $chart_data->green)
                                                <div class="mr-2">
                                                    <div class="circle green"></div>
                                                </div>
                                                <div><small>Status (Green)</small></div>
                                            @elseif($chart->target_value < $chart_data->red)
                                                <div class="mr-2">
                                                    <div class="circle red"></div>
                                                </div>
                                                <div><small>Status (Red)</small></div>
                                            @else
                                                <div class="mr-2">
                                                    <div class="circle amber"></div>
                                                </div>
                                                <div><small>Status (Amber)</small></div>
                                            @endif
                                        @endif
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                @endif
            @endforeach
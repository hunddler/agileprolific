   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


    <script>
    
    
  

            function get_date(val,id)
            {
            var selectedDate = new Date(val);
            selectedDate.setDate(selectedDate.getDate() + 1);
            var newDateStr = selectedDate.toISOString().slice(0, 10);
            $('#' + id).attr('min',val);
            }

		
        function saveObjective() {

            var objective_name = $('#objective_name').val();
            var start_date = $('#start_date').val();
            var end_date = $('#end_date').val();        
            var detail = $('#obj_small_description').val();
            var org_id = "{{ $organization->org_id }}";
            var slug = "{{ $organization->slug }}";
            var unit_id = "{{ $organization->id }}";
            var type = "{{ $organization->type }}";
            var objective_status = $('#obj_status').val();


            if($('#objective_name').val() != '' || $('#start_date').val() != '' || $('#end_date').val() != '') {
                $.ajax({
                    type: "POST",
                    url: "{{ url('save-objective') }}",
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    data: {
                        objective_name: objective_name,
                        start_date: start_date,
                        end_date: end_date,
                        detail: detail,
                        org_id: org_id,
                        slug:slug,
                        unit_id:unit_id,
                        type:type,
                        objective_status:objective_status
                    },
                    success: function(res) {
                        // if (res == 1) {

                        //     $('#obj-name-error').html(
                        //         '<strong class="text-danger">Ojective Name Already Taken</strong>');

                        // } else {
                            $('#obj-name-error').html('');
                            $('#objective_name').val('');
                            $('#start_date').val('');
                            $('#end_date').val('');
                            $('#obj_small_description').val('');
                            $('#success-obj').html(
                                '<div class="alert alert-success" role="alert"> Objective Created successfully</div>'
                                );
                            $('#obj-feild-error').html('');
                            setTimeout(function() { 
                                $('#create-objective').modal('hide');
                                $('#success-obj').html('');
                                 }, 3000);
                              $('#parentCollapsible').html(res);

                        // }

                    }
                });
            } else {

                $('#obj-feild-error').html('Please fill out all required fields.');

            }
        }
        function editobjective(obj_id,obj_name,obj_start_date,obj_end_date,obj_detail,obj_status)
        {
         $('#edit_obj_id').val(obj_id);   
         $('#edit_objective_name').val(obj_name);   
         $('#edit_start_date').val(obj_start_date);   
         $('#edit_end_date').val(obj_end_date);   
         $('#edit_obj_small_description').val(obj_detail);   
         $('#edit_obj_status').val(obj_status);
        }

function UpdateObjective() {

        var edit_obj_id =  $('#edit_obj_id').val();   
        var edit_objective_name  = $('#edit_objective_name').val();   
        var edit_start_date = $('#edit_start_date').val();   
        var edit_end_date = $('#edit_end_date').val();   
        var edit_obj_small_description = $('#edit_obj_small_description').val();
        var org_id = "{{ $organization->org_id }}";
        var slug = "{{ $organization->slug }}";
        var unit_id = "{{ $organization->id }}";
        var status = $('#edit_obj_status').val();
         var type = "{{ $organization->type }}";
   

if ($('#edit_objective_name').val() != '' || $('#edit_start_date').val() != '' || $('#edit_end_date').val() != '') {
    $.ajax({
        type: "POST",
        url: "{{ url('update-objective') }}",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        data: {
            edit_objective_name: edit_objective_name,
            edit_start_date: edit_start_date,
            edit_end_date: edit_end_date,
            edit_obj_small_description:edit_obj_small_description,
            edit_obj_id:edit_obj_id,
            org_id:org_id,
            slug:slug,
            status:status,
            unit_id:unit_id,
            type:type
        },
        success: function(res) {
          
                $('#edit_objective_name').val('');
                $('#edit_start_date').val('');
                $('#edit_end_date').val('');
                $('#edit_obj_small_description').val('');
                $('#success-obj-edit').html(
                    '<div class="alert alert-success" role="alert"> Objective Updated successfully</div>'
                    );
                $('#oobj-feild-error-edit').html('');
                setTimeout(function() { 
                    $('#edit-objective').modal('hide');
                    $('#success-obj-edit').html('');
                     }, 3000);

                  $('#parentCollapsible').html(res);
                  $("#nestedCollapsible"+edit_obj_id).collapse('toggle');

            

        }
    });
} else {

    $('#obj-feild-error-edit').html('Please fill out all required fields.');

}
}


function deleteobj(obj_id)
{
    $('#obj_delete_id').val(obj_id);

}

function DeleteObjective() {

        var delete_obj_id =  $('#obj_delete_id').val();   
        var org_id = "{{ $organization->org_id }}";
        var slug = "{{ $organization->slug }}";
        var unit_id = "{{ $organization->id }}";
        var type = "{{ $organization->type }}";

        $.ajax({
        type: "POST",
        url: "{{ url('Delete-objective') }}",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        data: {
            delete_obj_id:delete_obj_id,
            org_id:org_id,
            slug:slug,
            unit_id:unit_id,
            type:type
        },
        success: function(res) {
  
        $('#success-obj-delete').html(
            '<div class="alert alert-success" role="alert"> Objective Deleted successfully</div>'
            );

        setTimeout(function() { 
            $('#delete-objective').modal('hide');
            $('#success-obj-delete').html('');
             }, 3000);

          $('#parentCollapsible').html(res);
          $("#nestedCollapsible"+delete_obj_id).collapse('toggle');


    

}
});

}



function objective(key_obj_id,w_count,start_date,end_date)
{
    $('#key_obj_id').val(key_obj_id);
    $('#key_start_date').attr('min',start_date); 
    $('#key_start_date').attr('max',end_date);
    $('#key_end_date').attr('max',end_date);

    $('#weight').html(''); 
    if(w_count == 0)
    {
     $(".check" ).prop("checked",false);

    }else
    {
    $('#weight').append('<div class="col-md-8"><input style="margin-top:10px;" class="range-slider__range-two  ml-4"  type="range" value="0" min="1" max="100"></div><div class="col-md-4"><input id="sliderValue" class="w-25 mt-2" readonly type="text" min="1" value="1"></div>'); // Add field html
    $(".check" ).hide();

  
    }
    
    


}

$(document).ready(function () {
    $('.check').on('click', function () {
        var isChecked = $(this).is(':checked');
         $('#wieght-error').html('');
        if (isChecked) {
             // Show the weight div
             $('#weight').html(''); 
              $('#weight').append('<div class="col-md-8"><input style="margin-top:10px;" class="range-slider__range-two  ml-4"  type="range" value="1" min="1" max="100"></div><div class="col-md-4"><input id="sliderValue" class="w-25 mt-2 range-slider__range-two"  type="text" min="1" value="1"></div>'); // Add field html

             
        } else {
            $('#weight').html(''); // Hide the weight div
        }
    });
});





$(document).ready(function () {
$(document).on('input', '.range-slider__range-two', function () {
        $('.range-slider__range-two').val($(this).val());
        $('#sliderValue').val($(this).val());
        var slider = $('#sliderValue').val();
       
        var obj = $('#key_obj_id').val();
        $.ajax({
        type: "GET",
        url: "{{ url('check-key-weight') }}",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        data: {
        obj:obj,
        slider:slider,

        },
        success: function(res) {
     
        if(res.key > 100)
        {
        $('#wieght-error').html('<small class="text-danger ml-2">Combined weight percentage must not be greater than 100</small>');
            
        }else
        {
         $('#wieght-error').html('');
        }



        }
    });
    
    });
});


function saveKeyObjective() {

var key_name = $('#key_name').val();
var key_start_date = $('#key_start_date').val();
var key_end_date = $('#key_end_date').val();
var key_detail = $('#key_detail').val();
var org_id = "{{ $organization->org_id }}";
var slug = "{{ $organization->slug }}";
var unit_id = "{{ $organization->id }}";
var obj_id = $('#key_obj_id').val();
var weight = $('#sliderValue').val();
var type = "{{ $organization->type }}";
var k_status = $('#key_status').val();


if ($('#key_name').val() != '' || $('#key_start_date').val() != '' || $('#key_end_date').val() != '') {
    $.ajax({
        type: "POST",
        url: "{{ url('save-objective-key') }}",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        data: {
            key_name: key_name,
            key_start_date: key_start_date,
            key_end_date: key_end_date,
            key_detail: key_detail,
            org_id: org_id,
            slug:slug,
            obj_id:obj_id,
            weight:weight,
            unit_id:unit_id,
            type:type,
            k_status:k_status
        },
        success: function(res) {
            // if (res == 1) {

            //     $('#obj-key-name-error').html(
            //         '<strong class="text-danger">Key Name Already Taken</strong>');

            // } else {
                $('#obj-key-name-error').html('');
                $('#key_name').val('');
                $('#key_start_date').val('');
                $('#key_end_date').val('');
                $('#key_detail').val('');
                 $('.range-slider__value-two').attr('min',1);
                 $('#sliderValue').val(1);
                 $( ".check" ).prop("checked",false);
                 $('#weight').html('');

                $('#success-obj-key').html(
                    '<div class="alert alert-success" role="alert"> Key Result Created successfully</div>'
                    );
                $('#key-feild-error').html('');
                setTimeout(function() { 
                    $('#create-key-result').modal('hide');
                    $('#success-obj-key').html('');
                     }, 3000);
                  $('#parentCollapsible').html(res);
                  $("#nestedCollapsible"+obj_id).collapse('toggle');
                  $('#wieght-error').html('');


            // }

        }
    });
} else {

    $('#key-feild-error').html('Please fill out all required fields.');

}
}



function editobjectivekey(key_id,key_name,key_start_date,key_end_date,key_detail,key_weight,obj_id)
        {
         $('#edit_key_obj_id').val(key_id);   
         $('#edit_key_name').val(key_name);   
         $('#edit_key_start_date').val(key_start_date);   
         $('#edit_key_end_date').val(key_end_date);   
         $('#edit_key_detail').val(key_detail);   
         $('#edit_key_obj').val(obj_id);
         $('#weight-edit').html('');
         $('#wieght-error-edit').html('');

   
         getkeyweight(key_id);
 

        }
        
        
    function getkeyweight(id)
        {
   
      
     
       var obj  = $('#edit_key_obj').val();
       
         $.ajax({
        type: "GET",
        url: "{{ url('weight-check-edit') }}",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        data: {
        id:id,
        obj:obj

        },
        success: function(res) {
          
        $('#weight-edit').html(res);



        }
    });

        }
        
        
       function getsliderrange(keyId) {
        var sliderContainer = $('#sliderContainer' + keyId);
        var rangeSlider = $('#rangeSlider' + keyId);
        var sliderValue = $('#sliderValue' + keyId);

        if ($('.checkedit').is(':checked')) {
            sliderContainer.show();
            $('#wieght-error-edit').html('');
            sliderValue.val(1);
        } else {
            sliderContainer.hide();
            $('#wieght-error-edit').html('');
            sliderValue.val(null);

        }

        rangeSlider.on('input', function() {
            var value = $(this).val();
            sliderValue.val(value);
            

        var obj = $('#edit_key_obj').val();
        var key = $('#edit_key_obj_id').val();
        $.ajax({
        type: "GET",
        url: "{{ url('check-key-weight-edit') }}",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        data: {
        obj:obj,
        value:value,
        key:key

        },
        success: function(res) {
            
      
        if(res.key > 100)
        {
        $('#wieght-error-edit').html('<small class="text-danger ml-2">Combined weight percentage must not be greater than 100</small>');
            
        }else
        {
         $('#wieght-error-edit').html('');
        }



        }
    });
        });
    }
        


        
        $(document).on('input', '.range-slider__range-one', function() {
            
        var sliderValue = $(this).val();

        // Update the corresponding text input
        $(this).closest('.col-md-8').next('.col-md-4').find('#sliderValueEdit').val(sliderValue);
        var key = $('#edit_key_obj_id').val();
        $('#rangevalue'+key).val(sliderValue);
        var weightedit = $('#sliderValueEdit').val();
      

        var obj = $('#edit_key_obj').val();
        
        $.ajax({
        type: "GET",
        url: "{{ url('check-key-weight-edit-first') }}",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        data: {
        obj:obj,
        weightedit:weightedit,
        key:key

        },
        success: function(res) {
            
      
        if(res.key > 100)
        {
        $('#wieght-error-edit').html('<small class="text-danger ml-2">Combined weight percentage must not be greater than 100</small>');
            
        }else
        {
         $('#wieght-error-edit').html('');
        }



        }
    });
    });

function updateKeyObjective() {

var edit_key_name = $('#edit_key_name').val();
var edit_key_start_date = $('#edit_key_start_date').val();
var edit_key_end_date = $('#edit_key_end_date').val();
var edit_key_detail = $('#edit_key_detail').val();
var org_id = "{{ $organization->org_id }}";
var slug = "{{ $organization->slug }}";
var unit_id = "{{ $organization->id }}";
var key_id = $('#edit_key_obj_id').val();
var obj_id = $('#edit_key_obj').val();
var edit_key_status = $('#edit_key_status').val();

 var weightedit = $('#sliderValue' + key_id).val();   

 var weightedit_1 = $('#sliderValueEdit').val();  

var type = "{{ $organization->type }}";




if ($('#edit_key_name').val() != '' || $('#edit_key_start_date').val() != '' || $('#edit_key_end_date').val() != '') {
    $.ajax({
        type: "POST",
        url: "{{ url('update-objective-key') }}",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        data: {
            edit_key_name: edit_key_name,
            edit_key_start_date: edit_key_start_date,
            edit_key_end_date: edit_key_end_date,
            edit_key_detail:edit_key_detail,
            org_id: org_id,
            slug:slug,
            key_id:key_id,
            weightedit:weightedit,
            weightedit_1:weightedit_1,
            obj_id:obj_id,
            edit_key_status:edit_key_status,
            unit_id:unit_id,
            type:type
        },
        success: function(res) {


                $('#key_name').val('');
                $('#key_start_date').val('');
                $('#key_end_date').val('');
                $('#key_detail').val('');
                $('#success-obj-key-edit').html(
                    '<div class="alert alert-success" role="alert"> Key Result Updated successfully</div>'
                    );
                $('#key-feild-error-edit').html('');
                setTimeout(function() { 
                    $('#edit-key-result').modal('hide');
                    $('#success-obj-key-edit').html('');
                     }, 3000);
                  $('#parentCollapsible').html(res);
                  $("#nestedCollapsible"+obj_id).collapse('toggle');
                   $('#wieght-error-edit').html('');


            

        }
    });
} else {

    $('#key-feild-error-edit').html('Please fill out all required fields.');

}
}

function deleteobjkey(key_id,obj)
{
    $('#key_delete_id').val(key_id);
    $('#key_delete_obj_id').val(obj);

}

function DeleteObjectivekey() {

var key_delete_id =  $('#key_delete_id').val();   
var org_id = "{{ $organization->org_id }}";
var slug = "{{ $organization->slug }}";
var unit_id = "{{ $organization->id }}";
var obj = $('#key_delete_obj_id').val();
var type = "{{ $organization->type }}";


$.ajax({
type: "POST",
url: "{{ url('Delete-objective-key') }}",
headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
},
data: {
    key_delete_id:key_delete_id,
    org_id:org_id,
    slug:slug,
    unit_id:unit_id,
    type:type
},
success: function(res) {
  
        $('#success-key-delete').html(
            '<div class="alert alert-success" role="alert"> Key Result Deleted successfully</div>'
            );

        setTimeout(function() { 
            $('#delete-objective-key').modal('hide');
            $('#success-key-delete').html('');
             }, 3000);

          $('#parentCollapsible').html(res);
          $("#nestedCollapsible"+obj).collapse('toggle');


    

}
});

}


function initiative(key_id,obj_id,count,start_date,end_date)
{
    $('#key_id_initiative').val(key_id);
    $('#obj_id_initiative').val(obj_id);

 $('#wieght-error-initiative').html('');
     
    $('#weight-initiative').html(''); 
    if(count == 0)
    {
     $(".checkweight" ).prop("checked",false);
         

    }else
    {
    $('#weight-initiative').append('<div class="col-md-8"><input style="margin-top:10px;" class="range-slider__range  ml-4"  type="range" value="0" min="1" max="100"></div><div class="col-md-4"><input id="sliderValueInit" class="w-25 mt-2" readonly type="text" min="1" value="1"></div>'); // Add field html
    $(".checkweight" ).hide();

  
   }
   
   $('#initiative_start_date').attr('min',start_date);
   $('#initiative_start_date').attr('max',end_date);
   $('#initiative_end_date').attr('max',end_date);
// var currentDate = new Date();

// var firstDayOfMonth = new Date(currentDate.getFullYear(), month, 1);
// firstDayOfMonth.setDate(firstDayOfMonth.getDate() + 1);
// var formattedDate = firstDayOfMonth.toISOString().slice(0, 10);
// document.getElementById('initiative_start_date').min = formattedDate;
// $('.monthdate').val(formattedDate);

}

$(document).ready(function () {
    $('.checkweight').on('click', function () {
        var isChecked = $(this).is(':checked');
         $('#wieght-error-initiative').html('');
        if (isChecked) {
             // Show the weight div
             $('#weight-initiative').html(''); 
              $('#weight-initiative').append('<div class="col-md-8"><input style="margin-top:10px;" class="range-slider__range  ml-4"  type="range" value="0" min="1" max="100"></div><div class="col-md-4"><input id="sliderValueInit" class="w-25 mt-2 range-slider__range"  type="text" min="1" value="1"></div>'); // Add field html

             
        } else {
            $('#weight-initiative').html(''); // Hide the weight div
        }
    });
});

$(document).ready(function () {
$(document).on('input', '.range-slider__range', function () {
    
       $('.range-slider__range').val($(this).val());
        $('#sliderValueInit').val($(this).val());
        var slider = $('#sliderValueInit').val();
        var obj = $('#key_id_initiative').val();
        $.ajax({
        type: "GET",
        url: "{{ url('check-initiative-weight') }}",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        data: {
        obj:obj,
        slider:slider,

        },
        success: function(res) {
     
        if(res.key > 100)
        {
        $('#wieght-error-initiative').html('<small class="text-danger ml-2">Combined weight percentage must not be greater than 100</small>');
            
        }else
        {
         $('#wieght-error-initiative').html('');
        }



        }
    });
    
    });
});


function saveKeyinitiative() {

var initiative_name = $('#initiative_name').val();
var initiative_start_date = $('#initiative_start_date').val();
var initiative_end_date = $('#initiative_end_date').val();
var initiative_detail = $('#initiative_detail').val();
var org_id = "{{ $organization->org_id }}";
var slug = "{{ $organization->slug }}";
var unit_id = "{{ $organization->id }}";
var key_id_initiative = $('#key_id_initiative').val();
var obj_id_initiative = $('#obj_id_initiative').val();
var slider = $('#sliderValueInit').val();
var type = "{{ $organization->type }}";
var init_status = $('#init_status').val();


if ($('#initiative_name').val() != '' || $('#initiative_start_date').val() != '' || $('#initiative_end_date').val() != '') {
    $.ajax({
        type: "POST",
        url: "{{ url('save-key-initiative') }}",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        data: {
            initiative_name: initiative_name,
            initiative_start_date: initiative_start_date,
            initiative_end_date: initiative_end_date,
            initiative_detail: initiative_detail,
            org_id: org_id,
            slug:slug,
            obj_id_initiative:obj_id_initiative,
            key_id_initiative:key_id_initiative,
            slider:slider,
            unit_id:unit_id,
            type:type,
            init_status:init_status

        },
        success: function(res) {
            // if (res == 1) {

            //     $('#initiative-name-error').html(
            //         '<strong class="text-danger">initiative Name Already Taken</strong>');

            // } else {
                $('#initiative-name-error').html('');
                $('#initiative_name').val('');
                $('#initiative_start_date').val('');
                $('#initiative_end_date').val('');
                $('#initiative_detail').val('');
                $('#success-initiative').html(
                    '<div class="alert alert-success" role="alert"> initiative Created successfully</div>'
                    );
                $('#initiative-feild-error').html('');
                setTimeout(function() { 
                    $('#create-initiative').modal('hide');
                    $('#success-initiative').html('');
                     }, 3000);
                  $('#parentCollapsible').html(res);
                  $("#nestedCollapsible"+obj_id_initiative).collapse('toggle');
                  $("#key-result"+key_id_initiative).collapse('toggle');
                  
                  $('.range-slider__range').attr('min',1);
                 $('#sliderValueInit').val(1);
                 $( ".checkweight" ).prop("checked",false);
                 $('#weight-initiative').html('');
                 $('#wieght-error-initiative').html('');


                  


            // }

        }
    });
} else {

    $('#initiative-feild-error').html('Please fill out all required fields.');

}
}


function deletekeyinitiative(initiative_id,key_id,obj_id)
{
    $('#initiative_delete_id').val(initiative_id);
    $('#initiative_delete_key_id').val(key_id);
    $('#initiative_delete_obj_id').val(obj_id);

}

function Deletekeyinitiative() {

var initiative_delete_id =  $('#initiative_delete_id').val();   
var org_id = "{{ $organization->org_id }}";
var slug = "{{ $organization->slug }}";
var unit_id = "{{ $organization->id }}";
var initiative_delete_key_id = $('#initiative_delete_key_id').val();
var initiative_delete_obj_id =   $('#initiative_delete_obj_id').val();
var type = "{{ $organization->type }}";


$.ajax({
type: "POST",
url: "{{ url('Delete-key-initiative') }}",
headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
},
data: {
    initiative_delete_id:initiative_delete_id,
    org_id:org_id,
    slug:slug,
    unit_id:unit_id,
    type:type
},
success: function(res) {
  
        $('#success-initiative-delete').html(
            '<div class="alert alert-success" role="alert"> Initiative Deleted successfully</div>'
            );

        setTimeout(function() { 
            $('#delete-initiative-key').modal('hide');
            $('#success-initiative-delete').html('');
             }, 3000);

          $('#parentCollapsible').html(res);
          $("#nestedCollapsible"+initiative_delete_obj_id).collapse('toggle');
          $("#key-result"+initiative_delete_key_id).collapse('toggle');


    

}
});

}

function editinitiative(initiative_id,initiative_name,initiative_start_date,initiative_end_date,initiative_detail,initiative_weight,initiative_key,initiative_obj)
        {
        
            
         $('#edit_id_initiative').val(initiative_id);   
         $('#edit_initiative_name').val(initiative_name);   
         $('#edit_initiative_start_date').val(initiative_start_date);   
         $('#edit_initiative_end_date').val(initiative_end_date);   
         $('#edit_initiative_detail').val(initiative_detail);
         $('#edit_id_initiative_key').val(initiative_key);
         $('#edit_id_initiative_obj').val(initiative_obj);
         
         getinitiativweight(initiative_id);
         $('#wieght-error-edit-init').html('');

        }
        
          function getinitiativweight(id)
        {
   
      $('#initiative-edit-weight').html('');
     
       var obj  = $('#edit_id_initiative_key').val();
       
         $.ajax({
        type: "GET",
        url: "{{ url('weight-initiative-edit') }}",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        data: {
        id:id,
        obj:obj

        },
        success: function(res) {
          
        $('#initiative-edit-weight').html(res);



        }
    });

        }
        
         function getsliderrangeinit(keyId) 
         {
        var sliderContainer = $('#sliderContainerinit' + keyId);
        var rangeSlider = $('#rangeSliderinit' + keyId);
        var sliderValue = $('#sliderValueinit' + keyId);

        if ($('.checkeditinit').is(':checked')) {
            sliderContainer.show();
            $('#wieght-error-edit-init').html('');
            sliderValue.val(1);
        } else {
            sliderContainer.hide();
            $('#wieght-error-edit-init').html('');
            sliderValue.val(null);

        }

        rangeSlider.on('input', function() {
            var value = $(this).val();
            sliderValue.val(value);
            

       
        var key = $('#edit_id_initiative_key').val();
        
        $.ajax({
        type: "GET",
        url: "{{ url('check-init-weight-edit') }}",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        data: {
        keyId:keyId,
        value:value,
        key:key

        },
        success: function(res) {
            
      
        if(res.key > 100)
        {
        $('#wieght-error-edit').html('<small class="text-danger ml-2">Combined weight percentage must not be greater than 100</small>');
            
        }else
        {
         $('#wieght-error-edit').html('');
        }



        }
    });
        });
    }
    
    
      $(document).on('input', '.range-slider__range_init', function() {
            
        var sliderValue = $(this).val();

        // Update the corresponding text input
        $(this).closest('.col-md-8').next('.col-md-4').find('#sliderValueEditinit').val(sliderValue);
        var weightedit = $('#sliderValueEditinit').val();
        var key = $('#edit_id_initiative_key').val();
        var init = $('#edit_id_initiative').val();
        $('#init_weight'+init).val(sliderValue);
      
        $.ajax({
        type: "GET",
        url: "{{ url('check-init-weight-edit-first') }}",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        data: {
        init:init,
        sliderValue:sliderValue,
        key:key

        },
        success: function(res) {
            
      
        if(res.key > 100)
        {
        $('#wieght-error-edit-init').html('<small class="text-danger ml-2">Combined weight percentage must not be greater than 100</small>');
            
        }else
        {
         $('#wieght-error-edit-init').html('');
        }



        }
    });
    });

function UpdateKeyinitiative() {

var edit_id_initiative = $('#edit_id_initiative').val();
var edit_initiative_name = $('#edit_initiative_name').val();
var edit_initiative_start_date = $('#edit_initiative_start_date').val();
var edit_initiative_end_date = $('#edit_initiative_end_date').val();
var org_id = "{{ $organization->org_id }}";
var slug = "{{ $organization->slug }}";
var unit_id = "{{ $organization->id }}";
var edit_initiative_detail = $('#edit_initiative_detail').val();
var sliderValue = $('#sliderValueinit' + edit_id_initiative).val();
var weightedit = $('#sliderValueEditinit').val();
var edit_initiative_status = $('#edit_initiative_status').val();

 var key_edit =  $('#edit_id_initiative_key').val();
 var obj_edit =  $('#edit_id_initiative_obj').val();
 var type = "{{ $organization->type }}";


if ($('#edit_initiative_name').val() != '' || $('#edit_initiative_start_date').val() != '' || $('#edit_initiative_end_date').val() != '') {
    $.ajax({
        type: "POST",
        url: "{{ url('update-key-initiative') }}",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        data: {
            edit_initiative_name: edit_initiative_name,
            edit_initiative_start_date: edit_initiative_start_date,
            edit_initiative_end_date: edit_initiative_end_date,
            edit_initiative_detail: edit_initiative_detail,
            org_id: org_id,
            slug:slug,
            edit_id_initiative:edit_id_initiative,
            sliderValue:sliderValue,
            weightedit:weightedit,
            key_edit:key_edit,
            edit_initiative_status:edit_initiative_status,
            unit_id:unit_id,
            type:type

        },
        success: function(res) {
           
                
                if(res == 1)
                {
                 $('#initiative-date-error').html('There are some items planned for this quarter. They need be removed.');
   
                }else
                {
                $('#initiative_name').val('');
                $('#initiative_start_date').val('');
                $('#initiative_end_date').val('');
                $('#initiative_detail').val('');
                $('#success-initiative-edit').html(
                    '<div class="alert alert-success" role="alert"> initiative Updated successfully</div>'
                    );
                $('#initiative-feild-error-edit').html('');
                setTimeout(function() { 
                    $('#edit-initiative').modal('hide');
                    $('#success-initiative-edit').html('');
                     }, 3000);
                  $('#parentCollapsible').html(res);
                  
                  $("#nestedCollapsible"+obj_edit).collapse('toggle');
                  $("#key-result"+key_edit).collapse('toggle');
                }
            

        }
    });
} else {

    $('#initiative-feild-error-edit').html('Please fill out all required fields.');

}
}






function addepic(ini_epic_id,epic_key,epic_obj)
{
    $('#ini_epic_id').val(ini_epic_id);
    $('#epic_key').val(epic_key);
    $('#epic_obj').val(epic_obj);

}
function saveEpic() {

var epic_name = $('#epic_name').val();
var epic_start_date = $('#epic_start_date').val();
var epic_end_date = $('#epic_end_date').val();
var epic_description = $('#epic_description').val();
var epic_story = $('#epic_story').val();
var org_id = "{{ $organization->org_id }}";
var slug = "{{ $organization->slug }}";
var unit_id = "{{ $organization->id }}";
var ini_epic_id = $('#ini_epic_id').val();
var epic_status = $('#epic_status').val();

var epic_key = $('#epic_key').val();
var epic_obj = $('#epic_obj').val();
var type = "{{ $organization->type }}";

   var epicData = [];
    $('.epic-input').each(function() {
        epicData.push($(this).val());
    });

if ($('#epic_name').val() != '' ) {
    $.ajax({
        type: "POST",
        url: "{{ url('save-epic') }}",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        data: {
            epic_name: epic_name,
            epic_start_date: epic_start_date,
            epic_end_date: epic_end_date,
            epic_description: epic_description,
            org_id: org_id,
            slug:slug,
            ini_epic_id:ini_epic_id,
            epicData:epicData,
            epic_status:epic_status,
            unit_id:unit_id,
            type:type,
            epic_obj:epic_obj
        },
        success: function(res) {
            // if (res == 1) {

            //     $('#obj-key-name-error').html(
            //         '<strong class="text-danger">Key Name Already Taken</strong>');

            // } else {
                $('#obj-key-name-error').html('');
                $('#epic_name').val('');
                $('#epic_start_date').val('');
                $('#epic_end_date').val('');
                $('#epic_description').val('');
                 $('#epic_story').val('');
                

                $('#success-epic').html(
                    '<div class="alert alert-success" role="alert"> Epic Created successfully</div>'
                    );
                $('#epic-feild-error').html('');
                setTimeout(function() { 
                    $('#create-epic').modal('hide');
                    $('#success-epic').html('');
                     }, 3000);
                  $('#parentCollapsible').html(res);
                  
                  $("#nestedCollapsible"+epic_obj).collapse('toggle');
                  $("#key-result"+epic_key).collapse('toggle');
                  $("#initiative"+ini_epic_id).collapse('toggle');
                  handleDivClick(ini_epic_id);


            // }

        }
    });
} else {

    $('#epic-feild-error').html('Please fill out all required fields.');

}
}


        function DeleteEpic(epicid,ini_epic,edit_epic_key,edit_epic_obj) 
        {
        
        
        var org_id = "{{ $organization->org_id }}";
        var slug = "{{ $organization->slug }}";
        var unit_id = "{{ $organization->id }}";
        var type = "{{ $organization->type }}";
        
            $.ajax({
                type: "POST",
                url: "{{ url('delete-epic') }}",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                data: {
                    epicid:epicid,
                    org_id:org_id,
                    slug:slug,
                    unit_id:unit_id,
                    type:type,
                    edit_epic_key:edit_epic_key,
                    edit_epic_obj:edit_epic_obj
                  
                },
                success: function(res) {
                  
        
                          
                   $('#parentCollapsible').html(res);
                  $("#nestedCollapsible"+edit_epic_obj).collapse('toggle');
                  $("#key-result"+edit_epic_key).collapse('toggle');
                  $("#initiative"+ini_epic).collapse('toggle');
                handleDivClick(ini_epic);

        
                    
        
                }
            });
        
        }




function editepic(epic_id,epic_name,epic_start_date,epic_end_date,epic_detail,epic_status,ini_epic_id,epic_key,epic_obj)
        {
         $('#epic_story_edit').html('');        
         $('#edit_epic_id').val(epic_id);   
         $('#edit_epic_name').val(epic_name);   
         $('#edit_epic_start_date').val(epic_start_date);   
         $('#edit_epic_end_date').val(epic_end_date);   
         $('#edit_epic_status').val(epic_status);
         
          $('#edit_ini_epic_id').val(ini_epic_id);
          $('#edit_epic_key').val(epic_key);
          $('#edit_epic_obj').val(epic_obj);
          

          $('#edit_epic_description').val(epic_detail);   


          
         
         getpicstory();
        }
        
      function getpicstory()
        {
         var edit_epic_id = $('#edit_epic_id').val();   
         
         $.ajax({
        type: "GET",
        url: "{{ url('edit-epic') }}",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        data: {
            edit_epic_id: edit_epic_id,

        },
        success: function(res) {
          
       

      $('#epic_story_edit').html(res);



        }
    });

        }
        
        
        function UpdateEpic() {
        
        var edit_epic_name = $('#edit_epic_name').val();
        var edit_epic_start_date = $('#edit_epic_start_date').val();
        var edit_epic_end_date = $('#edit_epic_end_date').val();
        var edit_epic_description = $('#edit_epic_description').val();
         var org_id = "{{ $organization->org_id }}";
        var slug = "{{ $organization->slug }}";
        var unit_id = "{{ $organization->id }}";
        var edit_epic_id = $('#edit_epic_id').val();
        var edit_epic_status = $('#edit_epic_status').val();
        
          var edit_ini_epic_id = $('#edit_ini_epic_id').val();
          var edit_epic_key = $('#edit_epic_key').val();
          var edit_epic_obj = $('#edit_epic_obj').val();
          var type = "{{ $organization->type }}";
        
     
        
        if ($('#edit_epic_name').val() != '') {
            $.ajax({
                type: "POST",
                url: "{{ url('update-epic') }}",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                data: {
                    edit_epic_name: edit_epic_name,
                    edit_epic_start_date: edit_epic_start_date,
                    edit_epic_end_date:edit_epic_end_date,
                    edit_epic_description: edit_epic_description,
                    org_id: org_id,
                    slug:slug,
                    edit_epic_id:edit_epic_id,
                    edit_epic_status:edit_epic_status,
                    edit_ini_epic_id:edit_ini_epic_id,
                    unit_id:unit_id,
                    type:type,
                    edit_epic_key:edit_epic_key,
                    edit_epic_obj:edit_epic_obj
                },
                success: function(res) {
                    // if (res == 1) {
        
                    //     $('#obj-key-name-error').html(
                    //         '<strong class="text-danger">Key Name Already Taken</strong>');
        
                    // } else {
                      
                        $('#edit_epic_name').val('');
                        $('#edit_epic_start_date').val('');
                        $('#edit_epic_end_date').val('');
                        $('#edit_epic_description').val('');
                        $('#success-epic-edit').html(
                            '<div class="alert alert-success" role="alert"> Epic Updated successfully</div>'
                            );
                        $('#epic-feild-error-edit').html('');
                        setTimeout(function() { 
                            $('#edit-epic').modal('hide');
                            $('#success-epic-edit').html('');
                             }, 3000);
                          $('#parentCollapsible').html(res);
                          
                  $("#nestedCollapsible"+edit_epic_obj).collapse('toggle');
                  $("#key-result"+edit_epic_key).collapse('toggle');
                  $("#initiative"+edit_ini_epic_id).collapse('toggle');
                  handleDivClick(edit_ini_epic_id);
                  
    
                         
        
        
                    // }
        
                }
            });
        } else {
        
            $('#epic-feild-error-edit').html('Please fill out all required fields.');
        
        }
        }    
        
    
        
        
    function getprogress(id)
        {
   
       var epicid = $('#edit_epic_id').val();
       var key = $('#edit_epic_key').val(); 
       var obj  = $('#edit_epic_obj').val();
       
         $.ajax({
        type: "POST",
        url: "{{ url('story-check') }}",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        data: {
        id:id,
        key:key,
        obj:obj

        },
        success: function(res) {
          
         $('#epic_story_edit').html(res);
         getalldata(epicid);



        }
    });

        }
        
        function updateprogress(id)
        {
   
         var epicid = $('#edit_epic_id').val();
         var key = $('#edit_epic_key').val();
         var obj  = $('#edit_epic_obj').val();
          
         $.ajax({
        type: "POST",
        url: "{{ url('update-story-check') }}",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        data: {
        id:id,
        key:key,
        obj:obj

        },
        success: function(res) {
          
         $('#epic_story_edit').html(res);
         getalldata(epicid);


        }
    });

        }


$(document).ready(function(){
    var maxField = 20; //Input fields increment limitation
    var addButton = $('.add_button'); //Add button selector
    var wrapper = $('.field_wrapper'); //Input field wrapper
    var fieldHTML = '<div class="d-flex w-75 mb-3"><br><br><input type="text" class="form-control epic-input"  id="epic_story" placeholder="Add Story" required><a href="javascript:void(0);"  class="remove_button btn btn-danger  mt-3  ml-3"><i class="fa fa-minus"></i></a></div>';

	var x = 1; //Initial field counter is 1
    
    //Once add button is clicked
    $(addButton).click(function(){
        //Check maximum number of input fields
        if(x < maxField){ 
            x++; //Increment field counter
            $(wrapper).append(fieldHTML); //Add field html
        }
    });
    
    //Once remove button is clicked
    $(wrapper).on('click', '.remove_button', function(e){
        e.preventDefault();
        $(this).parent('div').remove(); //Remove field html
        x--; //Decrement field counter
    });
});



    
   

	 //Initial field counter is 1
    
    //Once add button is clicked
  function addButton(epic) {
        var maxField = 1; // Allow only one input field
        var x = $('#field_wrapper_edit' + epic + ' .epic-input-edit').length;

        if (x < maxField) {
            var wrapper = $('#field_wrapper_edit' + epic); // Input field wrapper
            var fieldHTML = `
                <div class="w-75 mb-3">
                    <br><br>
                    <input type="hidden">
                    <input type="text" class="form-control epic-input-edit" id="" placeholder="Add Story" required>
                    <button class="btn btn-primary btn-lg btn-theme mt-3" type="button" onclick="addnewstory(${epic})">Add</button>
                    <a href="javascript:void(0);" class="btn btn-danger  mt-3 ml-3" id="remove_button_edit${epic}" onclick="removeButton(${epic})">Cancel</a>
                </div>
            `;

            $(wrapper).append(fieldHTML); // Add field html
            $('#item'+epic).hide();
        }
    }

    function removeButton(epic) {
        $('#field_wrapper_edit' + epic + ' .w-75').remove();
        $('#item'+epic).show();
    }
    
    
    function addnewstory(id)
        {
   
        var name = $('.epic-input-edit').val(); 
        var key = $('#edit_epic_key').val();
        var obj  = $('#edit_epic_obj').val();
        
        if ($('.epic-input-edit').val() != '') {
        $.ajax({
        type: "POST",
        url: "{{ url('add-story-new') }}",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        data: {
        id:id,
        name:name,
        key:key,
        obj:obj

        },
        success: function(res) {
          
         $('#field_wrapper_edit' + id + ' .w-75').remove();
         $('#epic_story_edit').html(res);
         
         getalldata(id);



        }
    });
    
        }

        }
        
         function editstory(story_id,name) 
         {
         $('.form-check'+story_id).addClass('d-none');
         $('#editbutton'+story_id).addClass('d-none');
         $('#' + story_id).append('<input type="text" class="form-control d-flex ml-3" id="title'+story_id+'" value="'+name+'"><div class="col-md-3 mt-2"><button class="btn btn-primary btn-sm update-button" onclick="updatestory('+story_id+')" type="button">Update</button></div>');
         }

     function updatestory(s_id)
        {
   
        var title = $('#title'+s_id).val(); 
        var key = $('#edit_epic_key').val();
         var obj  = $('#edit_epic_obj').val();
        
        if ($('.epic-input-edit').val() != '') {
        $.ajax({
        type: "POST",
        url: "{{ url('update-story') }}",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        data: {
        s_id:s_id,
        title:title,
        key:key,
        obj:obj

        },
        success: function(res) {
          
         $('#epic_story_edit').html(res);
         



        }
    });
    
        }

        }
        
        
     function deletestory(id)
        {
   
      
        var key = $('#edit_epic_key').val();
        var obj  = $('#edit_epic_obj').val();
        var epicid = $('#edit_epic_id').val();
        $.ajax({
        type: "POST",
        url: "{{ url('delete-story') }}",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        data: {
        id:id,
        key:key,
        obj:obj

        },
        success: function(res) {
          
         $('#epic_story_edit').html(res);
        getalldata(epicid);




        }
    });
    
        

        }
        
        
        
        function getalldata(id)
        {
   
    
        
        $.ajax({
        type: "GET",
        url: "{{ url('get-all-data') }}",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        data: {
        id:id,

        },
        success: function(res) {
          
         
       $('#progepic'+res.epic.id).width(res.epic.epic_progress +'%');
       $('#proginit'+res.initiative.id).width(res.initiative.initiative_prog +'%');
       $('#comp'+res.initiative.id).html(res.initiative.initiative_prog +'% Completed');
       
       $('#keycomp'+res.key.id).html(res.key.key_prog +'% Completed');
       $('#keyprog'+res.key.id).width(res.key.key_prog +'%');
       
       $('#obj_comp'+res.obj.id).html(res.obj.obj_prog +'% Completed');
       $('#obj_prog'+res.obj.id).width(res.obj.obj_prog +'%');
       
      $('#qcomp'+res.initiative.id).html(res.initiative.q_initiative_prog +'% Completed');
      $('#qkeycomp'+res.key.id).html(res.key.q_key_prog +'% Completed');

        }
    });
    
        

        }
 
 
 function getMonthStartAndEndDates(monthName, year) {
    
    const monthNames = [
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    ];


    const monthIndex = monthNames.indexOf(monthName);

    if (monthIndex === -1) {
      
        return null;
    }

    const startDate = new Date(year, monthIndex, 1);

   
    const endDate = new Date(year, monthIndex + 1, 0);

    return {
        start: startDate,
        end: endDate
    };
}

function formatDate(inputDate) {
 
  const dateObj = new Date(inputDate);

 
  if (!isNaN(dateObj.getTime())) {
   
    const year = dateObj.getFullYear();
    const month = String(dateObj.getMonth() + 1).padStart(2, '0');
    const day = String(dateObj.getDate()).padStart(2, '0'); 
  
    const formattedDate = `${year}-${month}-${day}`;

    return formattedDate;
  } else {
  
    return null;
  }
}
    
 
function addepicmonth(month_id,month_name,q_id,ini_epic_id,epic_key,epic_obj)
{
    
    $('#ini_epic_id_month').val(ini_epic_id);
    $('#epic_key_month').val(epic_key);
    $('#epic_obj_month').val(epic_obj);
    $('#month_id').val(month_id);
    $('#q_id').val(q_id);
    
    const monthName = month_name;
    const year = 2023;
    const { start, end } = getMonthStartAndEndDates(monthName, year);

// console.log("Start Date:", start.toDateString());
// console.log("End Date:", end.toDateString());


const formattedDate = formatDate(start.toDateString());
const endformattedDate = formatDate(end.toDateString());

 $('#epic_start_date_month').attr('min',formattedDate);
 
 $('#epic_start_date_month').val(formattedDate);
 $('#epic_end_date_month').val(endformattedDate);

// if (formattedDate) {
//   console.log(formattedDate); // Output: "2023-07-01"
// } else {
//   console.log("Invalid date.");
// }

}



function saveEpicMonth() {

var epic_name = $('#epic_name_month').val();
var epic_start_date = $('#epic_start_date_month').val();
var epic_end_date = $('#epic_end_date_month').val();
var epic_description = $('#epic_description_month').val();
var org_id = "{{ $organization->org_id }}";
var slug = "{{ $organization->slug }}";
var unit_id = "{{ $organization->id }}";
var ini_epic_id = $('#ini_epic_id_month').val();
var epic_status = $('#epic_status_month').val();

var epic_key = $('#epic_key_month').val();
var epic_obj = $('#epic_obj_month').val();

var epic_month = $('#month_id').val();
var epic_quartar = $('#q_id').val();
var type = "{{ $organization->type }}";

   var epicData = [];
    $('.epic-input').each(function() {
        epicData.push($(this).val());
    });

if ($('#epic_name_month').val() != '' ) {
    $.ajax({
        type: "POST",
        url: "{{ url('save-epic-month') }}",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        data: {
            epic_name: epic_name,
            epic_start_date: epic_start_date,
            epic_end_date: epic_end_date,
            epic_description: epic_description,
            org_id: org_id,
            slug:slug,
            ini_epic_id:ini_epic_id,
            epicData:epicData,
            epic_status:epic_status,
            epic_month:epic_month,
            epic_quartar:epic_quartar,
            unit_id:unit_id,
            type:type,
            epic_obj:epic_obj
            
        },
        success: function(res) {
            // if (res == 1) {

            //     $('#obj-key-name-error').html(
            //         '<strong class="text-danger">Key Name Already Taken</strong>');

            // } else {
               
                $('#epic_name_month').val('');
                $('#epic_start_date_month').val('');
                $('#epic_end_date_month').val('');
                $('#epic_description_month').val('');
              
                

                $('#success-epic-month').html(
                    '<div class="alert alert-success" role="alert"> Epic Created successfully</div>'
                    );
                $('#epic-feild-error-month').html('');
                setTimeout(function() { 
                    $('#create-epic-month').modal('hide');
                    $('#success-epic-month').html('');
                     }, 3000);
                  $('#parentCollapsible').html(res);
                  
                  $("#nestedCollapsible"+epic_obj).collapse('toggle');
                  $("#key-result"+epic_key).collapse('toggle');
                  $("#initiative"+ini_epic_id).collapse('toggle');
                  handleDivClick(ini_epic_id);
                   
            // }

        }
    });
} else {

    $('#epic-feild-error-month').html('Please fill out all required fields.');

}
}

function editepicflag(epic_id,flag_type,flag_title,flag__detail,ini_epic_id,epic_key,epic_obj)
        {
        
         $('#flag_epic_id').val(epic_id);   
         $('#flag_type').val(flag_type);   
         $('#flag_title').val(flag_title);   
          $('#flag_description').val(flag__detail);   
         $('#flag_ini_epic_id').val(ini_epic_id);
         $('#flag_epic_key').val(epic_key);
         $('#flag_epic_obj').val(epic_obj);
          
        }
        
        function FlgEpic() 
        {
        
        var flag_type = $('#flag_type').val();
        var flag_title = $('#flag_title').val();
        var flag_description = $('#flag_description').val();
        var flag_assign = $('#flag_assign').val();
        var org_id = "{{ $organization->org_id }}";
        var slug = "{{ $organization->slug }}";
        var unit_id = "{{ $organization->id }}";
        var flag_epic_id = $('#flag_epic_id').val();

         var flag_ini_epic_id = $('#flag_ini_epic_id').val();
         var flag_epic_key = $('#flag_epic_key').val();
         var flag_epic_obj = $('#flag_epic_obj').val();
         var type = "{{ $organization->type }}";
        
     
        
        if ($('#flag_type').val() != '') {
            $.ajax({
                type: "POST",
                url: "{{ url('update-epic-flag') }}",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                data: {
                    flag_type:flag_type,
                    flag_title: flag_title,
                    flag_description:flag_description,
                    org_id: org_id,
                    slug:slug,
                    flag_epic_id:flag_epic_id,
                    flag_assign:flag_assign,
                    unit_id:unit_id,
                    type:type
                },
                success: function(res) {
                   
                      
                        $('#success-flag').html(
                            '<div class="alert alert-success" role="alert">Epic Flag Updated successfully</div>'
                            );
                        $('#success-flag-error').html('');
                        setTimeout(function() { 
                            $('#edit-epic-flag').modal('hide');
                            $('#success-flag').html('');
                             }, 3000);
                             
                          $('#parentCollapsible').html(res);
                          
                  $("#nestedCollapsible"+flag_epic_obj).collapse('toggle');
                  $("#key-result"+flag_epic_key).collapse('toggle');
                  $("#initiative"+flag_ini_epic_id).collapse('toggle');
                  handleDivClick(flag_ini_epic_id);
                          
                         
        
        
                    
        
                }
            });
        } else {
        
            $('#success-flag-error').html('Please fill out all required fields.');
        
        }
        }  


var currentSectionIndex = 0;

function handleDivClick(x)
{
         $.ajax({
         type: "GET",
        url: "{{ url('get-month') }}",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        data: {
        x:x,

        },
        success: function(response) {
            
            // $("#initiative"+x).collapse('toggle');    
             currentSectionIndex = response.loop_index;
            var container = document.querySelector("#container-scroll-" + x);
            var sections = Array.from(document.querySelectorAll("#section-"+x));
    
              if (currentSectionIndex < sections.length - 1) {
               currentSectionIndex;
        
               var sectionWidth = sections[0].offsetWidth;
               container.style.transform = `translateX(-${sectionWidth * currentSectionIndex}px)`;

    }
        }
    });  
    

}

// $(document).ready(function(){
// 	var maxLength = 240;
// 	$(".show-read-more").each(function(){
// 		var myStr = $(this).text();
// 		if($.trim(myStr).length > maxLength){
// 			var newStr = myStr.substring(0, maxLength);
// 			var removedStr = myStr.substring(maxLength, $.trim(myStr).length);
// 			$(this).empty().html(newStr);
// 			$(this).append(' <a href="javascript:void(0);" class="read-more" style="color:black;">Read More...</a>');
// 			$(this).append('<span class="more-text">' + removedStr + '</span>');
			
// 		}
// 	});
// 	$(".read-more").click(function(){
// 		$(this).siblings(".more-text").contents().unwrap();
// 		$(this).remove();
// 	});
// });

        function loadmore(x){
        const toggleButton = document.getElementById("toggle-button" + x);
        const moreContent = document.querySelector(".more-content");
        const LoadmoreContent = document.querySelector(".load-more");

        toggleButton.addEventListener("click", function () {
                moreContent.style.display = "block";
                LoadmoreContent.style.display = "none";
            
        });
    }
    
    function seeless(x){
        const toggleButton = document.getElementById("toggle-button-less" + x);
        const moreContent = document.querySelector(".more-content");
        const LoadmoreContent = document.querySelector(".load-more");

        toggleButton.addEventListener("click", function () {
                moreContent.style.display = "none";
                LoadmoreContent.style.display = "block";
           
        });
    }
    
       function loadmoretext(x){
        const toggleButton = document.getElementById("toggle-button-text" + x);
        const moreContent = document.querySelector(".show-read-more-text");
        const LoadmoreContent = document.querySelector(".show-read-more");

        toggleButton.addEventListener("click", function () {
                moreContent.style.display = "block";
                LoadmoreContent.style.display = "none";
            
        });
    }
    
     function seelesstext(x){
        const toggleButton = document.getElementById("toggle-button-less-text" + x);
        const moreContent = document.querySelector(".show-read-more-text");
        const LoadmoreContent = document.querySelector(".show-read-more");

        toggleButton.addEventListener("click", function () {
                moreContent.style.display = "none";
                LoadmoreContent.style.display = "block";
           
        });
    }
    
    function saveQuarter() 
    {
        
        
        var org_id = "{{ $organization->org_id }}";
        var slug = "{{ $organization->slug }}";
        var unit_id = "{{ $organization->id }}";
        var type = "{{ $organization->type }}";
        
        var startdate = $('#q_start_date').val();
        var enddate = $('#q_end_date').val();
        var title = $('#q_title').val();
        var detail = $('#q_description').val();
        
            $.ajax({
                type: "POST",
                url: "{{ url('save-sprint') }}",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                data: {
                    startdate:startdate,
                    enddate:enddate,
                    title:title,
                    detail:detail,
                    org_id:org_id,
                    slug:slug,
                    unit_id:unit_id,
                    type:type,
                  
                },
                success: function(res) {
                  
               $('#success-sprint').html(
                            '<div class="alert alert-success" role="alert">Sprint Added successfully</div>'
                            );
                setTimeout(function() { 
                $('#create-report').modal('hide');
                $('#success-sprint').html('');
                }, 3000); 
                
                $('#sprint-end').html('<button class="button mr-1" onclick="endquarter();">End Quarter</button>');

               

        
                    
        
                }
            });
        
        }
        
       
       function endquarter()
        {
   
      
        $.ajax({
        type: "POST",
        url: "{{ url('end-sprint') }}",
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        data: {

        },
        success: function(res) {
          
        $('#sprint-end').html('<button class="button mr-1" data-toggle="modal" data-target="#create-report">Start Quarter</button>');



        }
    });
    
        

        }
    


    </script>